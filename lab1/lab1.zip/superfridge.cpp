#include "fridge.h"
#include <iostream>
using namespace std;

Fridge::Fridge()
{
    cout << "We have a superfridge!" << endl;
}
