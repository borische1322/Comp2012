#ifndef ELEPHANT_H
#define ELEPHANT_H

class Elephant
{
public:
    Elephant();
};

#endif
