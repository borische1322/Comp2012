#include "apple.h"
#include "elephant.h"

class Box
{
public:
    Box();
};
