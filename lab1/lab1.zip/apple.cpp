#include "apple.h"
#include <iostream>
using namespace std;

Apple::Apple()
{
    cout << "We have an apple!" << endl;
}
