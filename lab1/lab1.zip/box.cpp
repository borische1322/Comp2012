#include "box.h"
#include <iostream>
using namespace std;

Box::Box()
{
    Apple a;
    Elephant e;
    cout << "We have a box, it contains apples and elephants!" << endl;
}
