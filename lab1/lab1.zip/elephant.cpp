#include "elephant.h"
#include <iostream>
using namespace std;

Elephant::Elephant()
{
    cout << "We have an elephant!" << endl;
}
