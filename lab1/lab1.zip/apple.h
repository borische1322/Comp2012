#ifndef APPLE_H
#define APPLE_H

class Apple
{
public:
    Apple();
};

#endif