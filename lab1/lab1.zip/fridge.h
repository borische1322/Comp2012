class Fridge
{
public:
    Fridge();
};
